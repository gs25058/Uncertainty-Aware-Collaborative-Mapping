"""Planning-only progress towards human decisions, using current observations.

The coarse potential admits unknown space and does NOT assert human support,
connectivity, or reachability. It only weights where evidence would be useful.
Human/ReferenceValidator remain the sole decision/evaluation implementations.
"""
from dataclasses import dataclass
import numpy as np
from scipy import ndimage, sparse
from scipy.sparse.csgraph import dijkstra
from covor.entry.assignment import visible_fraction
from .sensing import camera_pose


@dataclass
class Query:
    key: str
    feet: np.ndarray
    body: np.ndarray
    foot_known: np.ndarray
    body_known: np.ndarray
    foot_novelty: np.ndarray
    goals: dict
    kind: str


class TaskContext:
    def __init__(self, analysis, lab, layer, ijk, res, cfg, prior):
        self.lab=lab; self.layer=layer; self.ijk=np.asarray(ijk); self.res=res
        self.opt=cfg['utility']['task_progress']; self.prior=prior
        self.factor=int(self.opt.get('coarse_rows',4)); f=self.factor
        shape=np.array(lab.shape); pad=(-shape)%f
        occupied=np.pad(lab==2,[(0,int(v)) for v in pad],constant_values=True)
        unknown=np.pad(lab==0,[(0,int(v)) for v in pad],constant_values=False)
        dims=occupied.shape; blocks=tuple(v//f for v in dims)
        reshape=(blocks[0],f,blocks[1],f,blocks[2],f)
        self.blocked=occupied.reshape(reshape).any(axis=(1,3,5))
        unknown_fraction=unknown.reshape(reshape).mean(axis=(1,3,5))
        self.shape=np.array(blocks); xyz=np.indices(blocks).reshape(3,-1).T
        world=(xyz*f+self.ijk+f/2)*res
        lo,hi=np.asarray(prior['exploration_box'])
        allowed=((world>=lo)&(world<=hi)).all(1).reshape(blocks)
        self.allowed=allowed&~self.blocked
        # Hypothetical body centres, never flight waypoints or confirmed feet.
        costs=1.+self.opt.get('unknown_travel_penalty',1.)*unknown_fraction
        ids=np.arange(np.prod(blocks)).reshape(blocks); row=[];col=[];values=[]
        for axis in range(3):
            a=[slice(None)]*3;b=a.copy();a[axis]=slice(None,-1);b[axis]=slice(1,None)
            a=tuple(a);b=tuple(b);good=self.allowed[a]&self.allowed[b]
            u=ids[a][good];v=ids[b][good]
            c=(costs[a][good]+costs[b][good])*.5*f*res
            if axis==2:c*=self.opt.get('vertical_cost',2.)
            row.extend([u,v]);col.extend([v,u]);values.extend([c,c])
        self.network=sparse.csr_matrix((np.concatenate(values),(np.concatenate(row),np.concatenate(col))),shape=(ids.size,ids.size))
        self.ids=ids; self.world=world
        self.entry_distance=self.distance(prior['entry'])
        self.goal_distance={};self.best={};self.decisions={d['goal']:d for d in analysis['decisions']}
        for goal in prior['goals']:
            if self.decisions[goal['id']]['verdict']!='unverified':continue
            dest=self.region_ids(goal);self.goal_distance[goal['id']]=self.distance(goal)
            self.best[goal['id']]=float(np.min(self.entry_distance[dest])) if len(dest) else np.inf
        self.queries=[]
        self.boundary_queries(analysis)
        for goal in prior['goals']:
            decision=self.decisions[goal['id']]
            if decision['verdict']=='blocked':continue
            if decision['verdict']=='passable':
                self.path_query(goal,decision)
            else:self.goal_query(goal)

    def region_ids(self, region):
        x0,y0,x1,y1=region['xy_bounds']; z0,z1=region['floor_z_bounds']
        # Public nominal floor interval, solely a planning query assumption.
        z=(z0+z1)/2+.45
        w=self.world;inside=(w[:,0]>=x0)&(w[:,0]<=x1)&(w[:,1]>=y0)&(w[:,1]<=y1)&(abs(w[:,2]-z)<=self.factor*self.res*.55)
        return np.flatnonzero(inside&self.allowed.ravel())

    def distance(self, region):
        nodes=self.region_ids(region)
        if not len(nodes):return np.full(self.ids.size,np.inf)
        return dijkstra(self.network,directed=False,indices=nodes,min_only=True)

    def index(self, point):
        q=np.floor((np.asarray(point)/self.res-self.ijk)/self.factor).astype(int)
        if ((q>=0)&(q<self.shape)).all():return int(self.ids[tuple(q)])
        return None

    def alignment(self, point):
        node=self.index(np.asarray(point)+[0,0,.45]);out={}
        if node is None:return out
        slack=self.opt.get('route_slack_m',2.)
        for goal,distance in self.goal_distance.items():
            a=self.entry_distance[node];b=distance[node];best=self.best[goal]
            if np.isfinite(a+b+best):out[goal]=float(np.exp(-max(0.,a+b-best)/slack))
            else:
                # Coarse max pooling can close a narrow real doorway. This
                # low-weight public-goal heuristic never certifies blockage.
                region=next(g for g in self.prior['goals'] if g['id']==goal)
                x0,y0,x1,y1=region['xy_bounds'];z0,z1=region['floor_z_bounds']
                centre=np.array([(x0+x1)/2,(y0+y1)/2,(z0+z1)/2])
                e=self.prior['entry'];e0,e1,e2,e3=e['xy_bounds'];entry=np.array([(e0+e2)/2,(e1+e3)/2,sum(e['floor_z_bounds'])/2])
                out[goal]=float(.2*np.exp(-max(0.,np.linalg.norm(point-centre)-np.linalg.norm(entry-centre))/slack))
            scale=self.opt.get('remaining_distance_scale_m')
            if scale:
                remaining=b if np.isfinite(b) else np.linalg.norm(point-centre)
                out[goal]*=float(scale/(scale+max(0.,remaining)))
        return out

    def query(self,key,feet,goals,kind):
        if not goals or not len(feet):return
        feet=np.asarray(feet,float);n=int(self.opt.get('query_samples',24))
        if len(feet)>n:feet=feet[np.linspace(0,len(feet)-1,n).astype(int)]
        # Crawl is the least permissive height REQUIRED to rule out all modes.
        # These points are enquiry samples; the actual full body test is intact.
        body=np.concatenate([feet+[0,0,z] for z in (.15,.45,.80)])
        if len(body)>n:body=body[np.linspace(0,len(body)-1,n).astype(int)]
        fi=np.floor(feet/self.res).astype(int)-self.ijk
        bi=np.floor(body/self.res).astype(int)-self.ijk
        valid=((fi>=0)&(fi<np.array(self.lab.shape))).all(1)
        feet=feet[valid];fi=fi[valid]
        bv=((bi>=0)&(bi<np.array(self.lab.shape))).all(1);body=body[bv];bi=bi[bv]
        if not len(feet) or not len(body):return
        known=np.zeros(len(fi),float);votes=np.zeros(len(fi),float)
        for delta in (-2,-1,0,1):
            q=fi.copy();q[:,2]+=delta;ok=((q>=0)&(q<np.array(self.lab.shape))).all(1);ix=np.flatnonzero(ok)
            h=self.layer['height'][tuple(q[ok].T)];near=np.isfinite(h)&(abs(h-feet[ok,2])<.15)
            known[ix]=np.maximum(known[ix],near*self.layer['support'][tuple(q[ok].T)])
            votes[ix]=np.maximum(votes[ix],near*self.layer['votes'][tuple(q[ok].T)])
        # Observed absence is useful evidence too, but never an invented floor.
        below=fi.copy();below[:,2]-=1;ok=(below[:,2]>=0)
        absent=np.zeros(len(fi),bool);absent[ok]=(self.lab[tuple(fi[ok].T)]==1)&(self.lab[tuple(below[ok].T)]==1)&(votes[ok]==0)
        known[absent]=1.
        bk=(self.lab[tuple(bi.T)]!=0).astype(float)
        novelty=np.where(known>0,0.,1/(1+votes/8.))
        self.queries.append(Query(key,feet,body,known,bk,novelty,goals,kind))

    def boundary_queries(self,analysis):
        g=analysis['graph'];offset=getattr(g,'map_offset',np.zeros(3,int))
        reach=np.zeros(g.lab.shape,bool)
        nodes=np.array(sorted(analysis['confirmed_search']['best']),int)
        if len(nodes):reach[tuple(g.xyz[nodes].T)]=True
        fringe=g.possible&~reach&ndimage.binary_dilation(reach,structure=np.ones((3,3,5),bool))
        points=np.argwhere(fringe)
        if not len(points):
            e=self.prior['entry'];x0,y0,x1,y1=e['xy_bounds'];z=sum(e['floor_z_bounds'])/2
            feet=np.array([[x,y,z] for x in np.linspace(x0,x1,4) for y in np.linspace(y0,y1,4)])
            self.query('entry_evidence',feet,{k:1. for k in self.goal_distance},'entry')
            return
        xyz=np.c_[g.node_xy[g.ids[tuple(points.T)]],g.foot_z[tuple(points.T)]-.025+.002]
        keys=np.floor(xyz/np.array([.8,.8,.3])).astype(int)
        patches=[]
        for key in np.unique(keys,axis=0):
            p=xyz[(keys==key).all(1)];align=self.alignment(np.median(p,axis=0))
            patches.append((sum(align.values()),tuple(key),p,align))
        for _,key,feet,align in sorted(patches,key=lambda p:(-p[0],p[1]))[:self.opt.get('max_boundary_patches',8)]:
            self.query('boundary_'+str(key),feet,align,'boundary')

    def goal_query(self,goal):
        x0,y0,x1,y1=goal['xy_bounds'];z0,z1=goal['floor_z_bounds']
        # Mission bounds contain the nominal floor, but never internal shapes.
        z=(z0+z1)/2
        feet=np.array([[x,y,z] for x in np.linspace(x0,x1,5) for y in np.linspace(y0,y1,5)])
        for k,p in enumerate(feet):
            q=np.floor(p/self.res).astype(int)-self.ijk
            if ((q>=0)&(q<np.array(self.lab.shape))).all():
                heights=self.layer['height'][q[0],q[1]]
                ids=np.flatnonzero(np.isfinite(heights)&(heights>=z0)&(heights<=z1))
                if len(ids):feet[k,2]=heights[ids[np.argmin(abs(heights[ids]-z))]]+.002
        self.query('goal_'+goal['id'],feet,{goal['id']:1.},'goal')

    def path_query(self,goal,decision):
        if not self.opt.get('stability_weight',0):return
        feet=np.array([p['xyz'] for p in decision['path']]);feet[:,2]-=.023
        # Only existing route queries; no reference route/mesh is available.
        self.query('route_check_'+goal['id'],feet,{goal['id']:1.},'stability')

    def observation_value(self,query,views,sd):
        def visible(points,needed):
            if not np.any(needed):return 0.
            pts=points[needed];cells=np.floor(pts/self.res).astype(int)-self.ijk
            best=0.
            for T in views:
                v=visible_fraction(cells,self.lab,self.ijk,self.res,T,sd,points_override=pts,max_range_m=sd.cfg.z_max)
                best=max(best,v['fraction']-self.opt.get('unknown_occlusion_discount',.5)*v['through_unknown'])
            return best
        fk=query.foot_known.mean();bk=query.body_known.mean()
        fv=visible(query.feet,query.foot_known<1)
        bv=visible(query.body,query.body_known<1)
        fn=float(query.foot_novelty.mean())
        af=min(1.,fk+fv*fn);ab=min(1.,bk+bv*(1-bk))
        return max(0.,min(af,ab)-min(fk,bk)),dict(foot_before=float(fk),body_before=float(bk),foot_visible=fv,body_visible=bv,foot_after=float(af),body_after=float(ab),foot_novelty=fn)


def augment(scored,analysis,lab,layer,ijk,res,sd,cfg,prior):
    context=analysis.get('_task_context')
    if context is None:
        context=TaskContext(analysis,lab,layer,ijk,res,cfg,prior);analysis['_task_context']=context
    opt=cfg['utility']['task_progress']
    for item in scored:
        c=item['candidate'];views=[camera_pose(np.array(c['position']),c['yaw'],p,cfg['sensor']['baseline']) for p in cfg['candidates']['pitches']]
        channels={k:{} for k in ('completion','boundary','goal','stability')};channels['completion']=item['targets'].copy();contributions=[]
        for query in context.queries:
            value,proof=context.observation_value(query,views,sd)
            kind='boundary' if query.kind=='entry' else query.kind
            for goal,weight in query.goals.items():channels[kind][goal]=max(channels[kind].get(goal,0.),value*weight)
            if value>0:contributions.append(dict(query=query.key,kind=query.kind,goals=query.goals,value=value,**proof))
        targets={}
        for kind,data in channels.items():
            weight=opt.get(kind+'_weight',0.)
            for goal,value in data.items():
                if opt.get('channel_aggregation','sum')=='max':targets[goal]=max(targets.get(goal,0.),weight*value)
                else:targets[goal]=targets.get(goal,0.)+weight*value
        novelty=1.;nearby=0
        history=analysis.get('_observed_views')
        radius=opt.get('view_novelty_radius_m',0.)
        if radius and history is not None and len(history):
            positions=np.asarray([v[0] for v in history]);headings=np.asarray([v[1] for v in history])
            distance=np.linalg.norm(positions-np.asarray(c['position']),axis=1)
            angle=abs((headings-c['yaw']+np.pi)%(2*np.pi)-np.pi)
            nearby=int(((distance<radius)&(angle<np.deg2rad(45))).sum())
            novelty=max(.05,1/(1+nearby/opt.get('view_novelty_scale',6.)))
        item['targets']={g:v*novelty for g,v in targets.items()};item['task_channels']=channels;item['view_novelty']=novelty
        item['objective_diagnostics']=dict(version=cfg['utility']['entry_objective'],queries=len(context.queries),hypothesis='coarse unknown-permitted task potential; not a confirmed human route',channels=channels,contributions=contributions,view_novelty=novelty,nearby_past_view_seconds=nearby)
    return scored
