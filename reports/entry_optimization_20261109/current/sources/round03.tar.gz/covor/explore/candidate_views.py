"""Optional COMMON camera-yaw repair, separately ablated from utility changes.

Candidate positions/counts, permitted pitch program, and flight constraints are
unchanged. Every policy receives this identical map-only orientation procedure.
"""
import copy
import numpy as np
from .entry_objective import TaskContext
from .sensing import camera_pose


def refine_body_views(pool,analysis,lab,layer,ijk,res,sd,cfg,prior):
    if not cfg['candidates'].get('body_reobserve_views'):return pool
    context=analysis.get('_candidate_task_context')
    if context is None:
        query_cfg=copy.deepcopy(cfg);query_cfg['utility']['task_progress']=cfg['candidates']['evidence_query_profile']
        context=TaskContext(analysis,lab,layer,ijk,res,query_cfg,prior);analysis['_candidate_task_context']=context
    queries=[q for q in context.queries if q.kind in ('boundary','entry')]
    if not queries:return pool
    result=[dict(c) for c in pool];n=min(cfg['candidates']['max_reobserve'],len(result))
    for candidate in result[-n:]:
        position=np.asarray(candidate['position']);old_yaw=candidate['yaw']
        def views(yaw):return [camera_pose(position,yaw,p,cfg['sensor']['baseline']) for p in cfg['candidates']['pitches']]
        before=max(context.observation_value(q,views(old_yaw),sd)[0] for q in queries)
        options=[]
        for q in queries:
            centre=q.body.mean(0);yaw=float(np.arctan2(centre[1]-position[1],centre[0]-position[0]))
            value,_=context.observation_value(q,views(yaw),sd);options.append((value,q.key,yaw))
        value,key,yaw=sorted(options,key=lambda x:(-x[0],x[1]))[0]
        if value>before+1e-8:
            candidate.update(yaw=yaw,kind='body_reobserve',orientation_source='common_observed_human_body_frontier',previous_yaw=old_yaw,target_query=key,visibility_before=before,visibility_after=value)
    return result
